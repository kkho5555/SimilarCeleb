// import * as tf from '@tensorflow/tfjs';
function opencvIsReady() {
  console.log('ready');
}

function readURL(input) {
  if (input.files && input.files[0]) {
    var reader = new FileReader();

    reader.onload = function (e) {
      $('.image-upload-wrap').hide();
      $('.file-upload-image').attr('src', e.target.result);
      $('.file-upload-content').show();

      $('.image-title').html(input.files[0].name);
      let utils = new Utils('errorMessage');
      utils.loadImageToCanvas(e.target.result, 'uploaded-image');
      //console.log(img);
      utils.loadOpenCv(() => {
        let eyeCascadeFile = './haarcascade_eye.xml';
        utils.createFileFromUrl(eyeCascadeFile, eyeCascadeFile, () => {
          let faceCascadeFile = './haarcascade_frontalface_default.xml';
          utils.createFileFromUrl(faceCascadeFile, faceCascadeFile, () => {
            // tryIt.removeAttribute('disabled');
          });
        });
      });
      let cvImg = faceDetect(utils);
    };

    reader.readAsDataURL(input.files[0]);
  } else {
    alert('img');
  }
}
function faceDetect(utils) {
  let src = cv.imread('uploaded-image');
  console.log(src);
  let gray = new cv.Mat();
  cv.cvtColor(src, gray, cv.COLOR_RGBA2GRAY, 0);
  console.log(gray);
  let faces = new cv.RectVector();
  let eyes = new cv.RectVector();
  let faceCascade = new cv.CascadeClassifier();
  let eyeCascade = new cv.CascadeClassifier();
  // load pre-trained classifiers

  faceCascade.load('./haarcascade_frontalface_default.xml');
  eyeCascade.load('./haarcascade_eye.xml');
  // detect faces
  let msize = new cv.Size(0, 0);
  faceCascade.detectMultiScale(gray, faces, 1.1, 3, 0, msize, msize);
  for (let i = 0; i < faces.size(); ++i) {
    let roiGray = gray.roi(faces.get(i));
    let roiSrc = src.roi(faces.get(i));
    let point1 = new cv.Point(faces.get(i).x, faces.get(i).y);
    let point2 = new cv.Point(
      faces.get(i).x + faces.get(i).width,
      faces.get(i).y + faces.get(i).height
    );
    cv.rectangle(src, point1, point2, [255, 0, 0, 255]);
    // detect eyes in face ROI
    eyeCascade.detectMultiScale(roiGray, eyes);
    for (let j = 0; j < eyes.size(); ++j) {
      let point1 = new cv.Point(eyes.get(j).x, eyes.get(j).y);
      let point2 = new cv.Point(
        eyes.get(j).x + eyes.get(j).width,
        eyes.get(j).y + eyes.get(j).height
      );
      cv.rectangle(roiSrc, point1, point2, [0, 0, 255, 255]);
    }
    roiGray.delete();
    roiSrc.delete();
  }
  cv.imshow('can', src);
  src.delete();
  gray.delete();
  faceCascade.delete();
  eyeCascade.delete();
  faces.delete();
  eyes.delete();
}

// async function init() {

//   const model = await tf.loadLayersModel('../celeb/tfjs_artifacts/model.json');
//   const img = document.getElementById('_img');
//   const tfImg = tf.browser.fromPixels(img);
//   const smalImg = tf.image.resizeBilinear(tfImg, [64, 64]);
//   const resized = tf.cast(smalImg, 'float32');
//   const t4d = tf.tensor4d(Array.from(resized.dataSync()), [1, 64, 64, 3]);

//   const labelContainer = document.getElementById('label-container');
//   for (let i = 0; i < 10; i++) {
//     // and class labels
//     labelContainer.appendChild(document.createElement('div'));
//   }
//   //const example = tf.fromPixels(img); // for example
//   const prediction = await model.predict(t4d, true);
//   console.log(model.summary());
//   const divv = document.getElementById('_div');
//   console.log();
//   divv.innerHTML = prediction.dataSync();
// }
// init();
